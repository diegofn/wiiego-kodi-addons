#/*
# *
# * ColombiaTV: ColombiaTV add-on for Kodi.
# *
# * Copyleft 2013-2018 Wiiego
# *
# * This program is free software: you can redistribute it and/or modify
# * it under the terms of the GNU General Public License as published by
# * the Free Software Foundation, either version 3 of the License, or
# * (at your option) any later version.
# *
# * This program is distributed in the hope that it will be useful,
# * but WITHOUT ANY WARRANTY; without even the implied warranty of
# * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# * GNU General Public License for more details.
# * 
# * You should have received a copy of the GNU General Public License
# * along with this program.  If not, see <http://www.gnu.org/licenses/>.
# *
# */
# *  based on https://gitorious.org/iptv-pl-dla-openpli/ urlresolver
# */
import sys

class ColombiaTVPluginSettings():

    def __init__(self):
        self.settings = sys.modules["__main__"].settings
        self.enabledeveloper = sys.modules["__main__"].enabledeveloper
        self.enabledebug = sys.modules["__main__"].enabledebug

    def enabledebug(self):
        return self.settings.getSetting("enabledebug") == "false"

    def enabledeveloper(self):
        return self.settings.getSetting("enabledeveloper") == "false"

